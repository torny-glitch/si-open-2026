# MSB Pickleball SI Open 2026 — website

Website giải đấu (Vite + React). Hai file chính:

- `src/main.jsx` — nội dung, dữ liệu và các thành phần giao diện
- `src/style.css` — toàn bộ giao diện (màu, phông chữ, bố cục)

## Cấu trúc thư mục (bắt buộc đúng)

```
si-open-2026/
├─ index.html
├─ package.json
├─ vite.config.js
└─ src/
   ├─ main.jsx
   └─ style.css
```

`index.html` gọi `/src/main.jsx`, nên hai file trong `src/` phải nằm đúng thư mục `src`.

## Chạy thử

1. Cài Node.js (bản LTS) từ https://nodejs.org/
2. `npm install`
3. `npm run dev` rồi mở địa chỉ hiện trong terminal
4. `npm run build` để kiểm tra bản chính thức

## Cập nhật thông tin giải

Mở `src/main.jsx`, sửa khối `EVENT` ở đầu file (ngày, giờ, địa điểm, tổng giải thưởng).
Điền `startISO` (ví dụ `2026-11-14T07:00:00+07:00`) để bật đồng hồ đếm ngược ở trang chủ.

Lịch thi đấu và danh sách VĐV: sửa `DEFAULT_MATCHES` / `DEFAULT_PLAYERS`, hoặc dùng
**Khu vực BTC** (liên kết ở chân trang) để nạp file Excel có hai sheet `Lịch thi đấu` và `Vận động viên`.
Bảng xếp hạng, bảng chéo và nhánh đấu tự tính từ cột `Tỉ số` (dạng `3-1`).

Dữ liệu nạp qua Khu vực BTC chỉ lưu trong trình duyệt của người nạp (localStorage), không hiển thị cho
khách truy cập khác. Muốn công khai: sửa dữ liệu trong mã nguồn rồi triển khai lại, hoặc nối cơ sở dữ liệu.

## Triển khai Vercel

Đưa mã lên GitHub → Vercel → Add New Project → chọn repo. Framework: Vite, build `npm run build`, output `dist`.
